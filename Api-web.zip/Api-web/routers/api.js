const express = require('express');
const router = express.Routers();

let items = [
  { id: 1, name: 'Item uno' },
  { id: 2, name: 'Item dos' }
];

router.get('/items', (req, res) => {
  res.json(items);
});

module.exports = routers;
